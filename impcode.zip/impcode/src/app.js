let Promise = require('bluebird')
let express = require('express')
let mysql = require('mysql')
let app = express()
let cors = require('cors')

Promise.promisifyAll(require("mysql/lib/Connection").prototype);
Promise.promisifyAll(require("mysql/lib/Pool").prototype);

//Body params to JSON
app.use(express.json())

//Ublocking CORS policy
app.use(cors())

   let DB_INFO = {
      host:"localhost",
      user:"root",
      password:"mahi@007",
      database:"nodejs"
  };
  


let checkUser = async (input) => {
    const connection = mysql.createConnection(DB_INFO);
    await connection.connectAsync();
    
    let myQuery =
      "select * from user where email = ? and pass = ?";
      const result = await connection.queryAsync(myQuery, [
        input.email,
        input.pass,
    ]);
    await connection.endAsync();
    if(result.length === 0){
      throw new Error("Invalid credentials")
    }
};

app.post("/checkuser", async (req, res) => {
    try {
      const input = req.body; 
        console.log(input)
      await checkUser(input);
      console.log('Done');
      res.json({ opr : true });
    } 
    catch (err) {
      console.log('error');
      res.json({ opr : false });
    }
});

let addUser = async (input) => {
    const connection = mysql.createConnection(DB_INFO);
    await connection.connectAsync();
    
    let myQuery =
      "insert into user (firstname, lastname, mobile, email, pass) values(? , ? , ? , ? , ?)"
      await connection.queryAsync(myQuery, [
        input.firstname,
        input.lastname,
        input.mobile,
        input.email,
        input.pass,
    ]);
    await connection.endAsync();
    //if(result.length === 0){
      //throw new Error("Invalid credentials")
    //}
}

app.post("/adduser" , async (req, res) => {
    try{
        let userData = req.body;
        console.log(userData);
        await addUser(userData);
        res.json({ opr : true });
    }
    catch(err){
        res.json({ opr : false });
    }
})



/*forget pass*/
let checkIfUserExist = async (input) => {
  const connection = mysql.createConnection(DB_INFO);
  await connection.connectAsync();
  
  let myQuery =
    "select * from user where email = ?";
    const result = await connection.queryAsync(myQuery, [
      input.email
  ]);
  await connection.endAsync();
  if(result.length === 0){
    throw new Error("Invalid credentials")
  }
};

app.post("/checkexist", async (req, res) => {
  try{
      let userData = req.body;
      console.log(userData);
      await checkIfUserExist(userData);
      res.json({ opr : true });
  }
  catch(err){
      res.json({ opr : false });
  }
})



let forgotPass = async (input) => {
  const connection = mysql.createConnection(DB_INFO);
    await connection.connectAsync();
    
    let myQuery =
      "update user set pass = ? where email = ?";
      const result = await connection.queryAsync(myQuery, [
        input.pass,
        input.email
    ]);
    await connection.endAsync();
    console.log(result, result.length)
    if(result.length === 0){
      throw new Error("Invalid credentials")
    }
}


app.post("/updateuser", async (req, res) => {
  try {
    const input = req.body; 
      console.log(input)
    await forgotPass(input);
    res.json({ opr : true });
  } 
  catch (err) {
    res.json({ opr : false });
  }
});
  
app.listen(3000)