import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-forgetpass',
  templateUrl: './forgetpass.component.html',
  styleUrls: ['./forgetpass.component.css']
})
export class ForgetpassComponent implements OnInit {
  public uiInvalidCredential = false;
  public fbFormGroup = this.fb.group({
    email:['', [Validators.required, Validators.pattern('[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')]],
    pass:['', [Validators.required, Validators.minLength(8), Validators.maxLength(15)]],
  });

  constructor(private fb: FormBuilder,
    private router:Router,
    private http: HttpClient) { }

  ngOnInit(): void { }

    async changePasswordProcess(){
      const updateURL = "http://localhost:3000/updateuser";
      const checkURL = "http://localhost:3000/checkexist";
      const userData = this.fbFormGroup.value;
      //console.log(userData);
  
      let checkResult : any = await this.http.post(checkURL, userData).toPromise();
      if(checkResult.opr){
        let result : any = await this.http.post(updateURL, userData).toPromise();
        if(result.opr)
        this.router.navigate(['login']);
  
      }
      else
        this.uiInvalidCredential = true;
    }
  }


