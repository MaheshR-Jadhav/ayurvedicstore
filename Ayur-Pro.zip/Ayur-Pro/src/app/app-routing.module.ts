import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HeaderComponent } from './header/header.component';
import { BodyComponent } from './body/body.component';
import { LoginComponent } from './login/login.component';
import { RegistrationComponent } from './registration/registration.component';
import { PageNotFoundComponent } from './page-not-found/page-not-found.component';
import { HomeComponent } from './home/home.component';
import { ForgetpassComponent } from './forgetpass/forgetpass.component';
import { Home1Component } from './home1/home1.component';
import { ProductsComponent } from './products/products.component';


const routes: Routes = [{path:'header', component:HeaderComponent},
 {path:'body', component:BodyComponent}, 
 {path:'login', component:LoginComponent},
{path:'registration', component:RegistrationComponent},
{path:'products', component:ProductsComponent},
{path:'home', component:HomeComponent},
{path:'home1', component:Home1Component},

{path:'', redirectTo:'/home1', pathMatch:'full'},
{path:'forgetpass', component:ForgetpassComponent},
{path:'**', component:PageNotFoundComponent},
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
