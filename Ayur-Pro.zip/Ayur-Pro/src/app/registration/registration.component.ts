import { Component, OnInit } from '@angular/core';
import { FormBuilder, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { HttpClient } from '@angular/common/http';

@Component({
  selector: 'app-registration',
  templateUrl: './registration.component.html',
  styleUrls: ['./registration.component.css']
})
export class RegistrationComponent implements OnInit {
  public fbFormGroup = this.fb.group({
    firstname:['', [Validators.required,Validators.pattern('[a-zA-Z]*')] ],
    lastname:['', [Validators.required,Validators.pattern('[a-zA-Z]*')]],
    mobile:['', [Validators.required,Validators.minLength(10),
      Validators.maxLength(10),
      Validators.pattern('[0-9]*')]],
    email:['', [Validators.required, Validators.pattern('[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}')]],
    pass:['', [Validators.required, Validators.minLength(8), Validators.maxLength(15)]],
  });

  constructor(private fb: FormBuilder,
     private router:Router,
     private http: HttpClient) { }

  ngOnInit(): void {}

   async registerHere(){
    const data =this.fbFormGroup.value;
    const url = "http://localhost:3000/adduser";

    await this.http.post(url, data).toPromise();

    this.router.navigate(['login']);
  }

}
